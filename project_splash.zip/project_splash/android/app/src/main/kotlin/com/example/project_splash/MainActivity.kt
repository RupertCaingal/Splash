package com.example.project_splash

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
